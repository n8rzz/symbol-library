/*jshint node:true */
/*global describe, it */
'use strict';

var assert = require('assert');

require('../lib/FunctionBind.js');

describe('Function.prototype.bind', function() {
    it('should', function() {
        // TODO: test this
        assert.ok(true);
    });
});
