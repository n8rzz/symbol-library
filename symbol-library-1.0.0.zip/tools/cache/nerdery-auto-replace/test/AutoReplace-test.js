/*jshint node:true */
/*global describe, it */
'use strict';

var assert = require('assert');
var AutoReplace = require('../lib/AutoReplace.js');

describe('AutoReplace', function() {
    describe('init', function() {
        it('should', function() {
            // TODO: test this
            assert.ok(true);
        });
    });

    describe('createChildren', function() {
        it('should', function() {
            // TODO: test this
            assert.ok(true);
        });
    });

    describe('enable', function() {
        it('should', function() {
            // TODO: test this
            assert.ok(true);
        });
    });

    describe('disable', function() {
        it('should', function() {
            // TODO: test this
            assert.ok(true);
        });
    });

    describe('destroy', function() {
        it('should', function() {
            // TODO: test this
            assert.ok(true);
        });
    });
});
