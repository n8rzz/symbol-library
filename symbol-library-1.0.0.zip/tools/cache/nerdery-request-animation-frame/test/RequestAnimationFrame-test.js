/*jshint node:true */
/*global describe, it */
'use strict';

var assert = require('assert');

require('../lib/RequestAnimationFrame.js');

describe('RequestAnimationFrame', function() {
    it('should', function() {
        // TODO: test this
        assert.ok(true);
    });
});
